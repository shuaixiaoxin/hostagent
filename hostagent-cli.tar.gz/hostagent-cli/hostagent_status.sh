#!/bin/bash
set -euo pipefail

# ==============================================================================
# 🎨 颜色与样式定义
# ==============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m'

# ==============================================================================
# 🛠️ 全局配置
# ==============================================================================
INSTALL_DIR="/usr/local/hostagent"
SERVICE_FILE="/etc/systemd/system/hostagent.service"
SERVICE_NAME="hostagent"

# ==============================================================================
# 🎯 辅助函数库
# ==============================================================================
print_separator() { echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"; }
print_separator_slim() { echo -e "${CYAN}───────────────────────────────────────────────────────────────────${NC}"; }
log_info() { echo -e "${BLUE}[INFO]${NC} 💡 $1"; }
log_success() { echo -e "${GREEN}[SUCCESS]${NC} ✅ $1"; }
log_warning() { echo -e "${YELLOW}[WARNING]${NC} ⚠️ $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} ❌ $1"; exit 1; }

check_installed() { [ -f "${SERVICE_FILE}" ] && [ -d "${INSTALL_DIR}" ]; }

get_service_status() {
    systemctl is-active --quiet ${SERVICE_NAME} && echo -e "${GREEN}● 运行中 (Active)${NC}" || echo -e "${RED}● 已停止 (Inactive)${NC}"
}

get_enable_status() {
    systemctl is-enabled --quiet ${SERVICE_NAME} 2>/dev/null && echo -e "${GREEN}已启用 (Enabled)${NC}" || echo -e "${YELLOW}已禁用 (Disabled)${NC}"
}

get_service_pid() { systemctl show -p MainPID --value ${SERVICE_NAME} 2>/dev/null; }

# 兼容无 bc 环境的字节格式化
format_bytes() {
    local bytes=$1
    if command -v numfmt &>/dev/null; then
        numfmt --to=iec --suffix=B --format="%.2f" "${bytes}" 2>/dev/null || echo "${bytes} B"
    else
        echo "$(( bytes / 1024 )) KB"
    fi
}

# 【新增】通过 Journal 日志统计历史启动次数（更真实）
get_historic_start_count() {
    # 统计过去 3 天内的启动次数，如果没有日志则返回 0
    local count=$(journalctl -u ${SERVICE_NAME} --since "3 days ago" --no-pager 2>/dev/null | grep -i "Started HostAgent" | wc -l)
    # 如果没搜到，尝试匹配更通用的 "Started" 描述
    if [ "$count" -eq 0 ]; then
        count=$(journalctl -u ${SERVICE_NAME} --since "3 days ago" --no-pager 2>/dev/null | grep -i "Started.*${SERVICE_NAME}" | wc -l)
    fi
    echo "${count:-0}"
}

# ==============================================================================
# 🔍 脚本主逻辑
# ==============================================================================
clear
echo -e "${CYAN}"
cat << "EOF"
    __  __           _        _   _        _               
   |  \/  | ___  ___| |_ __ _| |_| |_ __ _| |_ _   _ ___ 
   | |\/| |/ _ \/ __| __/ _` | __| __/ _` | __| | | / __|
   | |  | |  __/\__ \ || (_| | |_| || (_| | |_| |_| \__ \
   |_|  |_|\___||___/\__\__,_|\__|\__\__,_|\__|\__,_|___/
                                                             
           📊 HostAgent 一键状态巡检脚本 📊
EOF
echo -e "${NC}"
print_separator

# 1. 权限预检
log_info "正在执行环境预检..."
if [ "$EUID" -ne 0 ]; then 
    log_warning "当前非Root权限，部分日志和资源信息可能无法完整查看"
else
    log_success "Root权限校验通过，可获取完整巡检信息"
fi

# 2. 安装状态检测
print_separator_slim
log_info "正在检测 HostAgent 安装状态..."
if ! check_installed; then
    log_warning "未检测到 HostAgent 安装信息！"
    echo -e "${WHITE}📋 未发现：${NC} 服务文件或安装目录"
    log_info "请先执行安装脚本，脚本结束"
    print_separator
    exit 0
fi
log_success "检测到 HostAgent 已安装，开始全量巡检"

# ==============================================================================
# 模块1：基础安装状态
# ==============================================================================
print_separator_slim
echo -e "${WHITE}${BOLD}🔍 一、基础安装状态${NC}"
echo -e "   安装目录: ${INSTALL_DIR}"
echo -e "   服务文件: ${SERVICE_FILE}"

if [ -f "${INSTALL_DIR}/hostagent" ]; then
    BIN_PERM=$(stat -c "%a" "${INSTALL_DIR}/hostagent" 2>/dev/null)
    echo -e "   二进制文件: ${GREEN}存在${NC} (权限: ${BIN_PERM})"
else
    echo -e "   二进制文件: ${RED}缺失${NC}"
fi
[ -f "${INSTALL_DIR}/config.yaml" ] && echo -e "   配置文件: ${GREEN}存在${NC}" || echo -e "   配置文件: ${RED}缺失${NC}"

# ==============================================================================
# 模块2：Systemd服务状态
# ==============================================================================
print_separator_slim
echo -e "${WHITE}${BOLD}📊 二、Systemd 服务状态${NC}"
echo -e "   运行状态: $(get_service_status)"
echo -e "   开机自启: $(get_enable_status)"

SERVICE_ACTIVE=$(systemctl is-active ${SERVICE_NAME} 2>/dev/null)
if [ "${SERVICE_ACTIVE}" = "active" ]; then
    # 获取启动时间
    START_TIME=$(systemctl show -p ActiveEnterTimestamp --value ${SERVICE_NAME} 2>/dev/null | awk '{print $1,$2,$3}')
    
    # 直接使用 ps 获取已运行时间 (最稳健)
    MAIN_PID_TMP=$(get_service_pid)
    RUN_ETIME="N/A"
    [ -n "${MAIN_PID_TMP}" ] && [ "${MAIN_PID_TMP}" != "0" ] && RUN_ETIME=$(ps -p "${MAIN_PID_TMP}" -o etime= --no-headers 2>/dev/null | xargs)
    
    # 【修复】获取历史启动次数
    HISTORIC_STARTS=$(get_historic_start_count)

    echo -e "   本次启动时间: ${START_TIME}"
    echo -e "   本次连续运行: ${GREEN}${RUN_ETIME}${NC}"
    echo -e "   近3天内启动次数: ${CYAN}${HISTORIC_STARTS} 次${NC} (含手动/自动重启)"
else
    FAILED_TIME=$(systemctl show -p InactiveEnterTimestamp --value ${SERVICE_NAME} 2>/dev/null | awk '{print $2,$3}' || true)
    [ -n "${FAILED_TIME}" ] && echo -e "   停止时间: ${FAILED_TIME}"
    log_warning "服务未运行，执行: journalctl -u ${SERVICE_NAME} -f 查看原因"
fi

# ==============================================================================
# 模块3：进程运行详情
# ==============================================================================
print_separator_slim
echo -e "${WHITE}${BOLD}🚀 三、进程运行详情与资源占用${NC}"
MAIN_PID=$(get_service_pid)

if [ "${MAIN_PID}" != "0" ] && [ -n "${MAIN_PID}" ] && [ -d "/proc/${MAIN_PID}" ]; then
    PROC_INFO=$(ps -p ${MAIN_PID} -o ppid,%cpu,%mem,rss,vsize --no-headers 2>/dev/null)
    PROC_PPID=$(echo "${PROC_INFO}" | awk '{print $1}')
    CPU_USAGE=$(echo "${PROC_INFO}" | awk '{print $2}')
    MEM_USAGE=$(echo "${PROC_INFO}" | awk '{print $3}')
    RSS_BYTES=$(( $(echo "${PROC_INFO}" | awk '{print $4}') * 1024 ))
    VSIZE_BYTES=$(( $(echo "${PROC_INFO}" | awk '{print $5}') * 1024 ))

    NOFILE_LIMIT=$(cat /proc/${MAIN_PID}/limits | grep "Max open files" | awk '{print $4}' 2>/dev/null || echo "N/A")
    NOFILE_COUNT=$(ls /proc/${MAIN_PID}/fd 2>/dev/null | wc -l || echo "N/A")

    echo -e "   主进程 PID: ${GREEN}${MAIN_PID}${NC}"
    echo -e "   父进程 PPID: ${PROC_PPID}"
    echo -e "   CPU 使用率: ${CYAN}${CPU_USAGE}%${NC}"
    echo -e "   内存使用率: ${CYAN}${MEM_USAGE}%${NC}"
    echo -e "   物理内存占用: $(format_bytes ${RSS_BYTES})"
    echo -e "   虚拟内存占用: $(format_bytes ${VSIZE_BYTES})"
    echo -e "   文件句柄使用: ${NOFILE_COUNT} / ${NOFILE_LIMIT}"
else
    echo -e "   ${RED}未检测到运行中的进程${NC}"
fi

# ==============================================================================
# 模块4：最近日志
# ==============================================================================
print_separator_slim
echo -e "${WHITE}${BOLD}📝 四、最近10条运行日志${NC}"
if command -v journalctl &>/dev/null; then
    journalctl -u ${SERVICE_NAME} -n 10 --no-pager --output=short 2>/dev/null || echo -e "${YELLOW}暂无日志信息${NC}"
else
    echo -e "${YELLOW}未检测到 journalctl${NC}"
fi

# ==============================================================================
# 结尾
# ==============================================================================
print_separator_slim
echo -e "${WHITE}${BOLD}⚡ 常用快捷操作命令${NC}"
echo -e "   ${BLUE}● 实时日志:${NC} journalctl -u ${SERVICE_NAME} -f"
echo -e "   ${BLUE}● 重启服务:${NC} systemctl restart ${SERVICE_NAME}"
echo -e "   ${BLUE}● 编辑配置:${NC} vi ${INSTALL_DIR}/config.yaml"

print_separator
echo -e ""
echo -e "${GREEN}${BOLD}✅ HostAgent 状态巡检完成！${NC}"
echo -e ""
print_separator
