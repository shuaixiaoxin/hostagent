#!/bin/bash
set -euo pipefail

# ==============================================================================
# 🎨 颜色与样式定义 (ANSI Escape Codes)
# ==============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
BOLD='\033[1m'
NC='\033[0m' # No Color

# ==============================================================================
# 🛠️ 全局配置与辅助函数库
# ==============================================================================
INSTALL_DIR="/usr/local/hostagent-server"
SERVICE_FILE="/etc/systemd/system/hostagent-server.service"
SERVICE_NAME="hostagent-server"

# 打印炫酷分隔线
print_separator() {
    echo -e "${CYAN}╔═══════════════════════════════════════════════════════════════╗${NC}"
}

print_separator_slim() {
    echo -e "${CYAN}───────────────────────────────────────────────────────────────────${NC}"
}

# 日志级别输出
log_info() {
    echo -e "${BLUE}[INFO]${NC} 💡 $1"
}

log_success() {
    echo -e "${GREEN}[SUCCESS]${NC} ✅ $1"
}

log_warning() {
    echo -e "${YELLOW}[WARNING]${NC} ⚠️ $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} ❌ $1"
    exit 1
}

# 动态旋转进度条 (Spinner)
show_spinner() {
    local pid=$1
    local msg=$2
    local delay=0.1
    local spinstr='|/-\'
    
    echo -ne "${YELLOW}[PROC]${NC} ⏳ $msg "
    while [ -d "/proc/$pid" ]; do
        local temp=${spinstr#?}
        printf "[%c]  " "$spinstr"
        local spinstr=$temp${spinstr%"$temp"}
        sleep $delay
        printf "\b\b\b\b\b"
    done
    wait $pid 2>/dev/null
    echo -e "${GREEN}[Done]${NC}"
}

# 检查文件是否存在（仅安装时需要）
assert_file_exists() {
    if [ ! -f "$1" ]; then
        log_error "缺失关键文件: $1，请确保在当前目录下！"
    fi
}

# 检测是否已安装
check_installed() {
    if [ -f "${SERVICE_FILE}" ] && [ -d "${INSTALL_DIR}" ]; then
        return 0 # 已安装
    else
        return 1 # 未安装
    fi
}

# 获取服务运行状态
get_service_status() {
    if systemctl is-active --quiet ${SERVICE_NAME}; then
        echo -e "${GREEN}● 运行中 (Active)${NC}"
    else
        echo -e "${RED}● 已停止 (Inactive)${NC}"
    fi
}

# 获取开机自启状态
get_enable_status() {
    if systemctl is-enabled --quiet ${SERVICE_NAME} 2>/dev/null; then
        echo -e "${GREEN}已启用 (Enabled)${NC}"
    else
        echo -e "${YELLOW}已禁用 (Disabled)${NC}"
    fi
}

# 【核心】执行卸载逻辑
do_uninstall() {
    log_info "正在执行卸载程序..."
    
    # 停止服务
    (
        systemctl stop ${SERVICE_NAME} 2>/dev/null || true
        systemctl disable ${SERVICE_NAME} 2>/dev/null || true
        sleep 0.3
    ) & show_spinner $! "停止并禁用服务"

    # 删除服务文件
    (
        rm -f ${SERVICE_FILE}
        systemctl daemon-reload
        systemctl reset-failed 2>/dev/null || true
        sleep 0.3
    ) & show_spinner $! "清理系统服务注册"

    # 删除安装目录
    (
        rm -rf ${INSTALL_DIR}
        sleep 0.3
    ) & show_spinner $! "删除程序目录与文件"
    
    # 清理日志
    (
        journalctl --rotate --vacuum-time=1s -u ${SERVICE_NAME} 2>/dev/null || true
        sleep 0.2
    ) & show_spinner $! "清理系统日志"

    log_success "HostAgent 卸载完成"
}

# 【核心】执行安装逻辑
do_install() {
    log_info "正在开始部署..."
    
    # 1. 创建目录
    (
        mkdir -p ${INSTALL_DIR}/
        sleep 0.3
    ) & show_spinner $! "布局文件系统目录"
    log_success "目录创建完成: ${INSTALL_DIR}/"

    # 2. 部署二进制文件
    (
        cp -f hostagent-server ${INSTALL_DIR}/
        chmod +x ${INSTALL_DIR}/hostagent-server
        sleep 0.3
    ) & show_spinner $! "复制 HostAgent 核心程序"
    log_success "二进制文件部署完成"

    # 3. 部署配置文件
    (
        cp -f config.yaml ${INSTALL_DIR}/
        sleep 0.2
    ) & show_spinner $! "写入 config.yaml 配置"
    log_success "配置文件同步完成"

    print_separator_slim

    # 4. 注册 Systemd 服务
    log_info "正在注册 Systemd 系统服务..."
    cat > ${SERVICE_FILE} <<EOF
[Unit]
Description=HostAgent Collection Tool 📊
After=network.target syslog.target
Wants=network.target

[Service]
Type=simple
User=root
Group=root
WorkingDirectory=${INSTALL_DIR}/
ExecStart=${INSTALL_DIR}/hostagent-server -c config.yaml
Restart=always
RestartSec=5s
TimeoutStartSec=30s
TimeoutStopSec=10s
LimitNOFILE=65535
LimitNPROC=4096
StandardOutput=journal+console
StandardError=journal+console
SyslogIdentifier=hostagent-server

[Install]
WantedBy=multi-user.target
EOF
    (
        systemctl daemon-reload
        sleep 0.2
    ) & show_spinner $! "重载 Systemd 守护进程"
    log_success "服务配置文件注册完成"

    # 5. 启动服务
    log_info "正在启动 HostAgent 守护进程..."
    (
        systemctl start ${SERVICE_NAME}
        sleep 1
    ) & show_spinner $! "唤醒服务进程"

    # 6. 服务状态校验
    if systemctl is-active --quiet ${SERVICE_NAME}; then
        log_success "服务运行状态: $(get_service_status)"
    else
        log_warning "服务启动异常，请检查日志"
    fi

    print_separator_slim

    # 7. 配置开机自启
    log_info "正在配置开机自启策略..."
    (
        systemctl enable ${SERVICE_NAME} &>/dev/null
        sleep 0.2
    ) & show_spinner $! "设置开机自启规则"
    log_success "开机自启状态: $(get_enable_status)"
}

# 打印安装成功的页脚
print_install_footer() {
    print_separator
    echo -e ""
    echo -e "${GREEN}${BOLD}🎉 HostAgent 部署圆满完成！🎉${NC}"
    echo -e ""
    echo -e "${WHITE}📋 常用操作命令：${NC}"
    echo -e "   ${BLUE}● 查看状态:${NC} systemctl status ${SERVICE_NAME}"
    echo -e "   ${BLUE}● 实时日志:${NC} journalctl -u ${SERVICE_NAME} -f"
    echo -e "   ${BLUE}● 重启服务:${NC} systemctl restart ${SERVICE_NAME}"
    echo -e "   ${BLUE}● 配置文件:${NC} ${INSTALL_DIR}/config.yaml"
    print_separator
    echo -e ""
}

# 打印卸载成功的页脚
print_uninstall_footer() {
    print_separator
    echo -e ""
    echo -e "${GREEN}${BOLD}🗑️  HostAgent 卸载操作已完成！🗑️${NC}"
    echo -e ""
    print_separator
    echo -e ""
}

# ==============================================================================
# 🚀 脚本主逻辑入口
# ==============================================================================
clear
echo -e "${PURPLE}"
cat << "EOF"
    __  __           _    _                    _   
   |  \/  | ___  ___| |_(_) __ _  ___ _ __   | |_ 
   | |\/| |/ _ \/ __| __| |/ _` |/ _ \ '_ \  | __|
   | |  | | (_) \__ \ |_| | (_| |  __/ | | | | |_ 
   |_|  |_|\___/|___/\__|_|\__, |\___|_| |_|  \__|
                            |___/                    
           🚀 HostAgent 运维工具箱 🚀
EOF
echo -e "${NC}"
print_separator

# 1. 权限预检
log_info "正在进行环境预检..."
if [ "$EUID" -ne 0 ]; then 
    log_error "请使用 ${BOLD}root${NC} 权限运行此脚本 (执行: sudo su 切换)"
fi
log_success "Root权限校验通过"

# 2. 状态检测与主菜单
print_separator_slim
if check_installed; then
    log_warning "检测到系统已安装 HostAgent！"
    echo -e "${WHITE}📊 当前安装状态：${NC}"
    echo -e "   服务状态: $(get_service_status)"
    echo -e "   开机自启: $(get_enable_status)"
    echo -e "   安装路径: ${INSTALL_DIR}"
    echo -e ""
    echo -e "${BOLD}🛠️  请选择运维操作：${NC}"
    echo -e "   ${CYAN}[1]${NC} 覆盖升级安装（保留配置，仅更新程序）"
    echo -e "   ${CYAN}[2]${NC} 卸载后全新安装（清空旧数据，全新部署）"
    echo -e "   ${CYAN}[3]${NC} 仅卸载 HostAgent（彻底移除）"
    echo -e "   ${CYAN}[4]${NC} 退出"
    echo -ne "${BLUE}👉 请输入选项编号 (1-4): ${NC}"
    read -r user_choice

    case ${user_choice} in
        1)
            log_info "已选择【覆盖升级安装】模式"
            assert_file_exists "hostagent-server"
            assert_file_exists "config.yaml"
            (systemctl stop ${SERVICE_NAME} 2>/dev/null || true) & show_spinner $! "停止正在运行的服务"
            do_install
            print_install_footer
            ;;
        2)
            log_info "已选择【卸载后全新安装】模式"
            assert_file_exists "hostagent-server"
            assert_file_exists "config.yaml"
            do_uninstall
            print_separator_slim
            do_install
            print_install_footer
            ;;
        3)
            log_info "已选择【仅卸载 HostAgent】模式"
            echo -ne "${RED}${BOLD}⚠️  确认彻底卸载？输入 y 继续: ${NC}"
            read -r confirm
            if [[ ! ${confirm,,} =~ ^(y|yes)$ ]]; then
                log_info "操作取消"
                exit 0
            fi
            do_uninstall
            print_uninstall_footer
            ;;
        4)
            log_info "用户主动退出，脚本结束"
            exit 0
            ;;
        *)
            log_error "无效的选项输入，操作终止"
            ;;
    esac
else
    log_info "未检测到已安装版本，进入全新安装模式"
    assert_file_exists "hostagent-server"
    assert_file_exists "config.yaml"
    do_install
    print_install_footer
fi
